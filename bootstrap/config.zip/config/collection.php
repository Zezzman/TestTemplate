<?php
return [
    'COLLECTION' => [
        'DIRECTORIES' => [
            'storage/'
        ]
    ]
];