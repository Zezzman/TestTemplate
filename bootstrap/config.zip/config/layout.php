<?php
return [
    'LAYOUT' => [
        // Default Layout set to layout.php
        'DEFAULT' => 'layout',
    ]
];