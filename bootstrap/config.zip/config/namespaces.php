<?php
// Namespaces
return [
    'NAMESPACES' => [
        "CONTROLLERS" => "App\\Controllers\\",
        "API" => "App\\API\\",
        "CLI" => "App\\CLI\\",
        "VIEW_MODELS" => "App\\ViewModels\\"
    ]
];